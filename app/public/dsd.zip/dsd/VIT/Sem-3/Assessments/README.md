# ModelSim Assessments

## Assessment - 1

- [Problem Statement - 01 All Gates](01%20-%20All%20Gates/)
- [Problem Statement - 02 Half Adder and Subtractor](02%20-%20Half%20Adder%20and%20Subtractor/)
- [Problem Statement - 03 Two Level Logic Circuit](03%20-%20Two%20Level%20Logic%20Circuit/)

## Assessment - 2

- [Problem Statement - 04 Half Operator](04%20-%20Half%20Operator/)
- [Problem Statement - 05 Full Adder Structural](05%20-%20Full%20Adder%20Structural/)
- [Problem Statement - 06 Full Adder Gate Level](06%20-%20Full%20Adder%20Gate%20Level/)

## Assessment - 3

- [Problem Statement - 07 4-Bit Ripple Carry Adder](07%20-%204-Bit%20Ripple%20Carry%20Adder/)
- [Problem Statement - 08 Full Subtractor](08%20-%20Full%20Subtractor/)
- [Problem Statement - 09 2-Bit Magnitude Comparator](09%20-%202-Bit%20Magnitude%20Comparator/)
- [Problem Statement - 10 8-to-1 Multiplexer](10%20-%208-to-1%20Multiplexer/)

## Assessment - 4

- [Problem Statement - 11 1-to-8 Demultiplexer](11%20-%201-to-8%20Demultiplexer/)
- [Problem Statement - 12 8-to-3 Encoder](12%20-%208-to-3%20Encoder/)
- [Problem Statement - 13 3-to-8 Decoder](13%20-%203-to-8%20Decoder/)
- [Problem Statement - 14 JK Flip-Flop](14%20-%20JK%20Flip-Flop/)

## Assessment - 5

- [Problem Statement - 15 D Flip-Flop](15%20-%20D%20Flip-Flop/)
- [Problem Statement - 16 T Flip-Flop](16%20-%20T%20Flip-Flop/)
- [Problem Statement - 17 SISO Register](17%20-%20SISO%20Register/)
- [Problem Statement - 18 SIPO Register](18%20-%20SIPO%20Register/)
- [Problem Statement - 19 PIPO Register](19%20-%20PIPO%20Register/)

## Assessment - 6

- [Problem Statement - 20 2-Bit Upcounter](20%20-%202-Bit%20Upcounter/)
- [Problem Statement - 21 3-bit Random Counter with JK](21%20-%203-bit%20Random%20Counter%20with%20JK/)
- [Problem Statement - 22 Moore Sequence Detector](22%20-%20Moore%20Sequence%20Detector/)
