#include <stdio.h>
#include <string.h>

#define MAX 100

typedef struct {
    char data[MAX];
    int top;
} Stack;

void push(Stack *stack, char data) {
    stack -> data[++stack -> top] = value;
}

char pop(Stack *stack) {
    return stack -> data[stack -> top--];
}

char peek(Stack *stack) {
    return stack -> data[stack -> top];
}

int is_empty(Stack *stack) {
    return stack -> top == -1;
}

int is_empty(Stack *stack) {
    return stack -> top == -1;
}


