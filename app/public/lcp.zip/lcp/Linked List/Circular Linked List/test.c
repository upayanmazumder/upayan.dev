#include <stdio.h>
#include <stdlib.h>

typedef struct Node
{
    int data;
    struct Node *next;
} Node;

Node *create_node(int data)
{
    Node *node = malloc(sizeof(Node));
    node->data = data;
    node->next = node;
    return node;
}

void insert_end(Node **head, int val)
{
    Node *node = create_node(val);
    if (!*head)
    {
        *head = node;
        return;
    }
    Node *tail = *head;
    while (tail->next != *head)
    {
        tail = tail->next;
    }
    tail->next = node;
    node->next = *head;
}

void delete_value(Node **head, int data) {
    if (!*head) {
        return;
    }
    Node *current = *head;
    Node *previous = NULL;
    do {}
}